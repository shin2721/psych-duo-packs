import mental_l01_ja from "./mental_l01.ja.json";
import mental_l02_ja from "./mental_l02.ja.json";
import mental_l03_ja from "./mental_l03.ja.json";
import mental_l04_ja from "./mental_l04.ja.json";
import mental_l05_ja from "./mental_l05.ja.json";

export const mentalData = [
  ...mental_l01_ja,
  ...mental_l02_ja,
  ...mental_l03_ja,
  ...mental_l04_ja,
  ...mental_l05_ja,
];

export const mentalData_ja = [
  ...mental_l01_ja,
  ...mental_l02_ja,
  ...mental_l03_ja,
  ...mental_l04_ja,
  ...mental_l05_ja,
];
