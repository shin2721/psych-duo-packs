import study_l01_ja from "./study_l01.ja.json";

export const studyData = [
  ...study_l01_ja,
];

export const studyData_ja = [
  ...study_l01_ja,
];
