import social_l01_ja from "./social_l01.ja.json";
import social_l02_ja from "./social_l02.ja.json";

export const socialData = [
  ...social_l01_ja,
  ...social_l02_ja,
];

export const socialData_ja = [
  ...social_l01_ja,
  ...social_l02_ja,
];
