import work_l01_ja from "./work_l01.ja.json";
import work_l02_ja from "./work_l02.ja.json";

export const workData = [
  ...work_l01_ja,
  ...work_l02_ja,
];

export const workData_ja = [
  ...work_l01_ja,
  ...work_l02_ja,
];
