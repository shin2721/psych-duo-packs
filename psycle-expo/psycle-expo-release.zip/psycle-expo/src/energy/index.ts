export {
    ENERGY_MAX, REGEN_MS, STREAK_BONUSES, PERFECT_BONUS,
    getEnergy, canStart, onAnswer, onLessonEnd,
    addEnergy, setEnergy, resetEnergy
} from "./engine";
