# Psycle Principles（レッスン作成仕様）

> **🚨 このファイルがレッスン作成仕様の唯一の正本です**  
> **ルール本文は、このファイル以外に書くことを禁止します**  
> **他のファイルで独自ルールを追加・変更することは許可しません**

---

## 📋 基本構造

### レッスン構成
- **10問固定** per lesson
- **2-3分で完了**
- **5-Phase Structure** 必須

### Phase構成

| Phase | 目的 | 必須 |
|-------|------|------|
| 1. Hook | 共感を引く | |
| 2. What | 現象を認識させる | |
| 3. Why | 原理を理解させる | |
| 4. How | 実践シミュレーション | **必須** |
| 5. Anchor | 振り返り・定着 | |

### Phase 4 ルール（Better Choice）

**Phase 4（How）では「正解/不正解」を使わない。**

| 禁止 | 推奨 |
|------|------|
| 「正解！」「不正解」 | 「Better Choice」「Recommended」 |
| 「○」「×」 | 「いい選択だね」「こっちの方が後悔が少ないかも」 |
| 赤/緑のジャッジ色 | ニュートラルな表現 |

---

## 🎯 コンテンツ原則

### 1. Life-Scene First

**問題の主語は「心理学原理」ではなく「ユーザーの生活シーン」**

| 禁止（原理ベース） | 推奨（シーンベース） |
|--------------------|---------------------|
| 「返報性の原理とは...」 | 「断れない飲み会に誘われた時...」 |
| 「サンクコスト効果について」 | 「もう見たくない映画、途中で出る？」 |
| 「損失回避バイアスを説明せよ」 | 「今の彼氏/彼女、別れるのが怖い？」 |

### 2. Evidence Grade

信頼性に応じて固定テンプレを使う。**一字一句変えない。**

#### 🥇 Gold（メタ分析/複数RCT）
> 複数の研究結果をまとめた分析で、
> 一貫した傾向が確認されています。
> 個人差はありますが、現時点で最も信頼度が高い知見です。

#### 🥈 Silver（単一RCT/大規模調査）
> この知見は、
> ・最初は実践や臨床の現場で使われ
> ・その後、同様の効果が何度も確認され
> ・今も心理支援の現場で使われています。

#### 🥉 Bronze（パイロット/観察研究）
> 初期段階の研究で示唆されています。
> 今後さらなる検証が必要ですが、
> 試してみる価値はありそうです。

**Evidence Grade は「レッスン完了画面」のみで表示する。**

#### Evidence Grade 定義詳細

**🥇 Gold Grade 基準:**
- メタ分析（複数研究の統合分析）
- システマティックレビュー
- 複数のRCT（ランダム化比較試験）で一貫した結果
- Cochrane Review等の高品質レビュー

**🥈 Silver Grade 基準:**
- 単一のRCT（ランダム化比較試験）
- 大規模観察研究（n>1000）
- 査読済み学術論文
- 複数の小規模研究で一貫した結果

**🥉 Bronze Grade 基準:**
- パイロット研究
- 小規模観察研究
- 予備的研究結果
- 理論的枠組みに基づく仮説

**⚠️ 重要:** `source_type` が "book" または "classic" の場合、`evidence_grade` は通常 Silver 以下が適切です。書籍や古典的研究でGoldを付与する場合は特別な理由が必要です。

#### 追跡可能性（Citation Trackability）

**全Evidence Cardは以下のいずれか1つ以上の追跡可能な引用情報が必須:**
- **DOI** (Digital Object Identifier)
- **PMID** (PubMed ID)  
- **ISBN** (書籍の場合)
- **公式URL** (政府機関・学術機関の公式サイト)

**例:**
- 学術論文: DOI または PMID
- 書籍: ISBN
- 政府レポート: 公式URL
- 古典的研究: DOI（再版論文）または ISBN（書籍版）

#### Safety Harbor（安全な表現）

**ユーザー表示面でも以下の安全な表現を使用:**
- 「〜の可能性がある」
- 「〜が報告されている」  
- 「〜に役立つかもしれない」
- 「〜という傾向が見られる」
- 「個人差があります」

**医療・治療に関する表現は一切使用禁止。**

## 品質レポート管理

**生成レポートポリシー:**
- `docs/_reports/` は機械生成物のため git 管理対象外
- レポートは CI artifact として保存・参照する
- ローカル開発では `npm run content:preflight` で最新レポート生成
- レポート内容の永続化が必要な場合のみ手動コミット

**対象レポート:**
- `lesson_inventory.md` - レッスン棚卸し
- `bronze_assertion_warnings.md` - Bronze断定表現警告
- `evidence_grade_inflation.md` - Evidence Grade インフレ警告
- `citation_trackability.md` - 引用追跡可能性
- `evidence_specificity.md` - Evidence薄さ警告
- `claim_alignment.md` - Claim整合性警告
- `verification_staleness.md` - Evidence鮮度警告（D-pack）
- `citation_format.md` - 引用形式エラー（D-pack）
- `needs_review.md` - 要再監査ステータス（D-pack）

## Evidence 鮮度管理（D-pack）

**自動劣化検知システム:**
- `last_verified` フィールドによる期限管理
- 365日超過: WARNING（再検証推奨）
- 730日超過: FAIL（要再検証）
- 科学は変わることを前提とした自動監視

**引用形式検証:**
- DOI: `10.` で始まる形式必須
- PMID: 数値のみ必須
- ISBN: ISBN-10/13形式必須
- URL: `http://` または `https://` 必須
- 全引用情報が空欄の場合は警告

**ステータス管理:**
- `status: active` - 現在有効で使用中
- `status: draft` - 作業中、未承認
- `status: needs_review` - 人間による再監査が必要
- `status: deprecated` - 無効、使用禁止
- `needs_review` ステータスは preflight で警告表示

### 3. 禁止表現（Vocabulary Hygiene）

#### FAIL（公開禁止）

| 表現 | 理由 |
|-----|------|
| 治る/治療できる/治療法 | 医療行為に該当 |
| 必ず/確実に/絶対/100% | 効果を保証 |
| 〜と証明された/科学的に確定 | 科学プロセスの誤解 |
| 人生が変わる/劇的に改善 | 誇大広告 |

#### WARN（要レビュー）

| 表現 | 推奨置換 |
|-----|---------|
| 高い効果 | 効果が報告されている |
| 多くの研究 | 複数の研究 |
| 一般に〜される | 〜と言われることがある |
| 効果的 | 役立つ可能性がある |

### 4. 文字数制限

- **Explanation**: 2-3行以内
- **問題文**: 具体的なディテールを2つ以上含む
- **選択肢**: 簡潔に

### 5. Evidence Card必須

**全レッスンにEvidence Cardが必要**
- ファイル名: `{lesson_name}.evidence.json`
- `human_approved: true` が本番配置の必要条件

### 6. 追跡可能性（Citation Trackability）

**監査に耐える引用の追跡可能性を確保**
- **追跡可能** = DOI or PMID or ISBN or 公式URL のいずれか1つ必須
- **book/classic** source_typeは DOI/PMID が無いケースがあるため ISBN/URL でOK
- **peer_reviewed** source_typeは DOI/PMID を優先、無ければ公式URL
- **systematic/meta** source_typeは DOI必須（例外なし）

---

## 🔄 運用モード

### Mode A 手順（人間が作る）

```bash
# 1. 上記仕様に従ってレッスン作成
# 2. data/lessons/{domain}_units/ に直接配置
# 3. インデックス更新とバリデーション
npm run gen:units
```

**ファイル配置:**
- **本番**: `data/lessons/{domain}_units/{domain}_l{nn}.ja.json`
- **Evidence Card**: `data/lessons/{domain}_units/{domain}_l{nn}.evidence.json`

### Mode B 手順（自動生成）

```bash
# 1. 自動生成（staging配置）
cd scripts/content-generator
npm run patrol

# 2. バリデーション
npm run validate:lessons

# 3. 承認（Evidence Card の human_approved を true に変更）

# 4. 昇格
npm run promote:lesson {domain} {basename}
```

**ファイル配置:**
- **staging**: `data/lessons/_staging/{domain}_units/{domain}_l{nn}.ja.json`
- **Evidence Card**: `data/lessons/_staging/{domain}_units/{domain}_l{nn}.evidence.json`

---

## ⚠️ 重要な制約

- **Mode B生成物は本番直入れ禁止** → 必ず staging 経由
- **Evidence Card必須** → レッスンJSONと同名の `.evidence.json` 必須
- **human_approved=true** → 本番配置の必要条件
- **staging配置必須** → Mode B は必ず staging に出力
- **承認ゲート** → 人間承認なしに本番配置不可
- **品質チェック必須** → Evidence/品質変更後は `npm run content:preflight` を必ず通す
- **CI必須** → CIが落ちる変更はレビュー前に修正

---

## 📊 Quality Gate（必須）

以下の条件を **1つでも満たさない場合、その問題セットは保存してはならない。**

| # | 失格条件 |
|---|----------|
| 1 | Life-Scene First が守られていない |
| 2 | Phase 4（How）が存在しない |
| 3 | 「正解／不正解」で行動を断定している |
| 4 | 科学的根拠の強度を誤解させる表現がある |
| 5 | 説教・一般論・教科書的説明になっている |
| 6 | Explanation が「別の視点・次に使える問い」ではなく「正解の断定」になっている |

### Fail Fast 原則

> **原則違反が1つでも検出された場合、当該コンテンツは「未完成」として扱い、出力・公開・推薦を行わない。**

**1つでも違反 → 修正必須。保存禁止。**

---

## 🔧 技術仕様

### JSON Schema
```json
{
  "id": "string",
  "type": "swipe_judgment | multiple_choice | select_all | sort_order | conversation",
  "question": "string",
  "domain": "string",
  "difficulty": "easy | medium | hard",
  "xp": "number",
  "explanation": "string (2-3行以内)",
  "actionable_advice": "string | null"
}
```

### Domain（必須）
| Domain | 保存先 |
|--------|--------|
| social | `social_units/` |
| mental | `mental_units/` |
| money | `money_units/` |
| health | `health_units/` |
| study | `study_units/` |
| work | `work_units/` |

**domain未定義 → 保存禁止（Fail Fast）**

---

## 🚨 仕様変更禁止

**このファイルが唯一の正本です。他の場所でルール本文を追加・変更することは禁止します。**

- 疑問があればこのファイルを更新
- 他ドキュメントでの独自ルール追加禁止
- Mode A/B で異なる仕様を作ることは禁止
