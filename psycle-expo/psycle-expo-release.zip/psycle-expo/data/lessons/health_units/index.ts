import health_l01_ja from "./health_l01.ja.json";

export const healthData = [
  ...health_l01_ja,
];

export const healthData_ja = [
  ...health_l01_ja,
];
