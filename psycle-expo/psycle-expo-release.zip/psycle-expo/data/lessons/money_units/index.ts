import money_l01_ja from "./money_l01.ja.json";

export const moneyData = [
  ...money_l01_ja,
];

export const moneyData_ja = [
  ...money_l01_ja,
];
